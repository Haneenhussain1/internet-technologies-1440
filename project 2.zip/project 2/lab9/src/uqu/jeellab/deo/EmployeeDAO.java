package uqu.jeellab.deo;
import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import uqu.jeelab.model.Employee;
public class EmployeeDAO {
	
	private static String URL = "db4free.net:3306/babybossproject";
	private static String user = "noormohammed";
	private static String password = "12345678";
	private Connection connect=null;
	private ResultSet resultSet=null;
	private ArrayList resList =new ArrayList();
	public ArrayList getEmployee() throws Exception{
		try {
			connect = DriverManager.getConnection ("jdbc:mysql://"+ URL,user,password);
			Statement statement = connect.createStatement();
			resultSet = statement.executeQuery("select * from Eployee");
				while(resultSet.next()) {
					String first_name=resultSet.getString("first_name");
					String last_name=resultSet.getString("last_name");
					resList.add(new Employee (first_name,last_name));
					
				}
				return resList;

		}
		catch (Exception e) {
			throw e;}finally { close();
			}}
private void close() {
	try {
		if (resultSet != null) {
			resultSet.close();
		}
		if (connect != null) {
			connect.close();
		}
	}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}
