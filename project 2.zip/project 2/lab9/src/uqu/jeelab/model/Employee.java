package uqu.jeelab.model;

public class Employee {
private String firstName;
private String lastName;
public Employee(String first_name,String last_name) {
	firstName =first_name;
	lastName=last_name;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}

}
